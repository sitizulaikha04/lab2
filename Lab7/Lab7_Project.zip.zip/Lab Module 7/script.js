// Slideshow
let slideIndex = 0;

function showSlides() {
  const slides = document.getElementsByClassName("slide");

  // Hide all slides
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }

  // Move to next slide
  slideIndex++;
  if (slideIndex > slides.length) {
    slideIndex = 1;
  }

  // Show current slide
  slides[slideIndex - 1].style.display = "block";

  // Change slide every 3 seconds
  setTimeout(showSlides, 3000);
}

document.addEventListener("DOMContentLoaded", showSlides);


// Progress Bar 
document.addEventListener("DOMContentLoaded", function () {
  const progressBar = document.getElementById("progress-bar");
  const increaseButton = document.getElementById("increase-progress");
  const resetButton = document.getElementById("reset-progress");

  let progress = 0;

  increaseButton.addEventListener("click", function () {
    if (progress < 100) {
      progress += 10;
      progressBar.style.width = progress + "%";
    } else {
      alert("Progress is complete!");
    }
  });

  resetButton.addEventListener("click", function () {
    progress = 0;
    progressBar.style.width = "0%";
  });
});


// Collapsible Section
document.addEventListener("DOMContentLoaded", function () {
  const collapsibleButton = document.querySelector(".collapsible");
  const content = document.querySelector(".content");

  collapsibleButton.addEventListener("click", function () {
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
});
